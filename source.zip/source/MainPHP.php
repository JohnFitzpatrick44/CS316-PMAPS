<?php
$username="username";
$password="password";
$database="username-databaseName";
?>